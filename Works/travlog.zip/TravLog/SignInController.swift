//
//  SignInController.swift
//  TravLog
//
//  Created by Paul D'Amora on 10/23/15.
//  Copyright © 2015 TravLog. All rights reserved.
//

import UIKit

class SignInController: UIViewController {
    // MARK: Properties
    // outlets for sign in form objects
    
    // MARK: Actions
    /* "Sign In" Button Press Event
        check email/phone id against online database
        procede to home screen
    */
}
