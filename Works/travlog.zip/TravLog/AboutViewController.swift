//
//  AboutViewController.swift
//  TravLog
//
//  Created by Ben Kaufman on 11/3/15.
//  Copyright © 2015 TravLog. All rights reserved.
//

import Cocoa

class AboutViewController: UIViewController {

}
