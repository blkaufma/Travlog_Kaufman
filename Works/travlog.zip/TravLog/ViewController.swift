//
//  ViewController.swift
//  TravLog
//
//  Created by Paul D'Amora on 10/22/15.
//  Copyright © 2015 TravLog. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Check if signed in; if not, prompt with main screen otherwise go to home screen
    }
}

