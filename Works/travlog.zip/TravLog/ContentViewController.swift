 //
//  ContentViewController.swift
//  TravLog
//
//  Created by Ben Kaufman on 11/3/15.
//  Copyright © 2015 TravLog. All rights reserved.
//

import UIKit

class ContentViewController: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var titleLable: UILabel!
}
