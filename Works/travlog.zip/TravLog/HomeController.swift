//
//  HomeController.swift
//  TravLog
//
//  Created by Paul D'Amora on 10/28/15.
//  Copyright © 2015 TravLog. All rights reserved.
//

import UIKit
import CoreLocation

class HomeController: UIViewController, CLLocationManagerDelegate {
    // MARK: Properties
    // outlets for home screen objects (pie chart, location, survey button)
    
    // MARK: Actions
    /* User leaves region
        add local push notification for x hours in the future
        survey waiting = true
    */
    
    
    // Initialize region monitoring
}
